"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const menu = [
  { nombre: "Inicio", ruta: "/" },
  { nombre: "Tareas Pendientes", ruta: "/tareas" },
  { nombre: "Aprobaciones pendientes", ruta: "/aprobaciones" },
  { nombre: "Administración de usuarios", ruta: "/usuarios" },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="flex h-screen w-[140px] shrink-0 flex-col border-r border-gray-600 bg-[#b3b3b3]">
      <div className="flex h-[130px] items-center justify-center">
        <div className="flex h-[60px] w-[46px] items-center justify-center rounded-lg bg-[#ff5b5b] text-sm text-black">
          LOGO
        </div>
      </div>

      <nav className="flex flex-col">
        {menu.map((item) => {
          const activo = pathname === item.ruta;

          return (
            <Link
              key={item.ruta}
              href={item.ruta}
              className={`flex min-h-[38px] items-center justify-center border-b border-gray-600 px-1 text-center text-[12px] text-black transition ${
                activo ? "bg-[#c7c7c7]" : "hover:bg-[#c0c0c0]"
              }`}
            >
              {item.nombre}
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto">
        <button
          type="button"
          className="h-[38px] w-full border border-gray-600 bg-[#ff7777] text-[12px] text-black hover:bg-[#ff6666]"
          onClick={() => alert("Aquí irá el cierre de sesión")}
        >
          Cerrar sesión
        </button>
      </div>
    </aside>
  );
}
