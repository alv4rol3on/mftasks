import Sidebar from "./Sidebar";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex h-screen w-full overflow-hidden">
      <Sidebar />

      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-[52px] shrink-0 items-center bg-[#e53939] px-4 text-white">
          Hola, &lt;Nombre de usuario&gt;
        </header>

        <section className="flex-1 overflow-auto bg-white p-4">
          {children}
        </section>
      </main>
    </div>
  );
}
