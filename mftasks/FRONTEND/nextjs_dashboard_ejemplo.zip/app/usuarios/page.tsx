export default function UsuariosPage() {
  return (
    <div>
      <h2 className="mb-4 text-lg font-medium">Administración de usuarios</h2>
      <p className="text-sm text-gray-600">
        Aquí podrás administrar los usuarios.
      </p>
    </div>
  );
}
