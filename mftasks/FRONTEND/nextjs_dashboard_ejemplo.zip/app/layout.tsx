import "./globals.css";
import DashboardLayout from "../components/DashboardLayout";

export const metadata = {
  title: "Dashboard",
  description: "Dashboard en Next.js",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body>
        <DashboardLayout>{children}</DashboardLayout>
      </body>
    </html>
  );
}
