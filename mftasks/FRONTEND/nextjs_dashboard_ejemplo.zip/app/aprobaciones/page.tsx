export default function AprobacionesPage() {
  return (
    <div>
      <h2 className="mb-4 text-lg font-medium">Aprobaciones pendientes</h2>
      <p className="text-sm text-gray-600">
        Aquí aparecerán las aprobaciones pendientes.
      </p>
    </div>
  );
}
