export default function TareasPage() {
  return (
    <div>
      <h2 className="mb-4 text-lg font-medium">Tareas Pendientes</h2>
      <p className="text-sm text-gray-600">
        Aquí aparecerán las tareas pendientes.
      </p>
    </div>
  );
}
