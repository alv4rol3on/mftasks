export default function Home() {
  return (
    <div>
      <h2 className="mb-5 text-sm font-medium">Alertas:</h2>

      <div className="rounded border border-gray-300 bg-gray-50 p-4 text-sm text-gray-600">
        No hay alertas pendientes.
      </div>
    </div>
  );
}
