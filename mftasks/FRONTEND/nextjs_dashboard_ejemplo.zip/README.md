# Dashboard Next.js

Ejemplo basado en la interfaz proporcionada.

## Requisitos

- Node.js 18.18 o superior
- npm

## Instalar

```bash
npm install
```

## Ejecutar

```bash
npm run dev
```

Luego abre:

http://localhost:3000

## Rutas

- `/` - Inicio
- `/tareas` - Tareas pendientes
- `/aprobaciones` - Aprobaciones pendientes
- `/usuarios` - Administración de usuarios

El siguiente paso podría ser conectar el nombre de usuario, las alertas y el cierre de sesión con tu backend/API.
